# Mini Expense

A simple browser-based expense total calculator.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/mini-expense/`
