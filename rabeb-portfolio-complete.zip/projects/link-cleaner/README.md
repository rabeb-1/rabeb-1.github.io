# Link Cleaner

A tiny tool that extracts a readable hostname from a URL.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/link-cleaner/`
