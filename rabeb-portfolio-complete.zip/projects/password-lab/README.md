# Safe Password Lab

A local learning tool that visualizes password strength.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/password-lab/`
