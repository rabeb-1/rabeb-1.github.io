# Study Sprint

A tiny focus timer for short study sessions.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/study-sprint/`
