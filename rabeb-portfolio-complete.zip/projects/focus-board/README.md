# Focus Board

A simple task board with filters and saved tasks.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/focus-board/`
