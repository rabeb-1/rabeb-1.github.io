# Daily Randomizer

A simple decision tool for choosing a small task.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/daily-randomizer/`
