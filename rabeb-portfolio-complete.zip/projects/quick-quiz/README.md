# Quick Quiz

A short JavaScript quiz with instant scoring.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/quick-quiz/`
