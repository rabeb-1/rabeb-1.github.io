# About Me Card

A minimal profile card with an interactive detail.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/about-card/`
