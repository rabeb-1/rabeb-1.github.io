# Cyber Checklist

A beginner-friendly checklist for everyday account security.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/cyber-checklist/`
