# Color Mood

A playful mood picker that changes the page.

## Built with
HTML, CSS, JavaScript

## Live demo
After publishing the portfolio repository with GitHub Pages:
`https://rabeb-1.github.io/projects/color-mood/`
