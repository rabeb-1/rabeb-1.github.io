# Rabeb Daafous — Portfolio

A simple personal portfolio built with HTML, CSS and JavaScript.

## About
Web development, cybersecurity analysis and problem solving.

## Projects
The `projects` folder contains 10 small projects, each with its own `index.html`.

## Contact
- Email: rabebdaafous@gmail.com
- GitHub: https://github.com/rabeb-1
- LinkedIn: https://www.linkedin.com/in/rabeb-daafous

## GitHub Pages
Repository name: `rabeb-1.github.io`
