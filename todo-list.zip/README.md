# To-Do List Web App

A simple and responsive task management app built with HTML, CSS, and JavaScript.

## Features

- Add tasks
- Mark tasks as completed
- Delete tasks
- Filter tasks by All, Active, or Completed
- Add due dates
- Dark/light mode
- Saves tasks using `localStorage`
- Responsive design

## Technologies

- HTML5
- CSS3
- JavaScript
- LocalStorage

## How to Run

Open `index.html` in your browser.

## Future Improvements

- Task editing
- Drag-and-drop task ordering
- Notifications for due dates
